package com.bdd.testrunners;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.TestNGCucumberRunner;

@CucumberOptions(
		//plugin = {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
		plugin = {"json:target/cucumber.json"},
		features = {"src/test/java/com/bdd/features"},
		glue= {"com.bdd.stepdefinitions"},
//plugin={"pretty","html:target/HtmlReports"},
//plugin= {"pretty","html:target/cucumber-report.html"},
		monochrome= true,
		publish=true
)

public class TestRunner extends AbstractTestNGCucumberTests  {
	TestNGCucumberRunner testngcucumber= new TestNGCucumberRunner(this.getClass());
	
}
