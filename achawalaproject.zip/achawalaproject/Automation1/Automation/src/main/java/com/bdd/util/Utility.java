package com.bdd.util;



import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Utility {

	public static WebDriver driver;
	
	public static long Pageload_Timeout=60;
	
	public static long Implecitly_Timeout=10;
	
	
	
	public void clearcacheusingjavascript() throws InterruptedException
	{
		String link="window.open();";
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript(link);
		Thread.sleep(2000);
		
		Set<String> handles= driver.getWindowHandles();
		String originalWindow= driver.getWindowHandle();
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()) {
			String newWindow= iterator.next();
			if(!originalWindow.equalsIgnoreCase(newWindow)) {
				driver.switchTo().window(newWindow);
				driver.get("chrome://settings/clearBrowserData");
				Thread.sleep(3000);
				WebElement e= driver.findElement(By.xpath("//setting-ui"));
				e.sendKeys(Keys.TAB);
				e.sendKeys(Keys.TAB);e.sendKeys(Keys.TAB);e.sendKeys(Keys.TAB);e.sendKeys(Keys.TAB);e.sendKeys(Keys.TAB);e.sendKeys(Keys.TAB);
				e.sendKeys(Keys.ENTER);
				Thread.sleep(3000);
				driver.close();
			driver.switchTo().window(originalWindow);
			}
			
		}
	}
	
}
