package com.bdd.pageobject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Listeners;

import static com.bdd.util.Utility.*;

import java.io.IOException;
import java.util.List;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.bdd.base.Base_Class;
import com.bdd.excelreader.ReadExcel;
import com.bdd.locators.ApplicationLocator;
import com.bdd.stepdefinitions.Stepdefinition;
import com.bdd.util.Utility;


public class Register_Page_object extends Base_Class {

	//ReadExcel excelbook= new ReadExcel();
	
	public static Logger log=LogManager.getLogger(Register_Page_object.class);
	
	By fname=By.xpath(ApplicationLocator.First_name);
	
	By lname= By.xpath(ApplicationLocator.Last_name);
	
	By address= By.xpath(ApplicationLocator.Address);
	
	By email=By.xpath(ApplicationLocator.Email);
	
	By phone= By.xpath(ApplicationLocator.Phone);
	
	By gender= By.xpath(ApplicationLocator.Gender);
	
	By hobbies= By.xpath(ApplicationLocator.Hobbies);
	
	By language_Click= By.xpath(ApplicationLocator.langauage_click);
	
	By language_select= By.xpath(ApplicationLocator.language_Select);
	
	By skills= By.xpath(ApplicationLocator.Skill);
	
	By skill_select= By.xpath(ApplicationLocator.Skill_click);
	
	By skill_name= By.xpath(ApplicationLocator.Skill_name);
	
	By year_click= By.xpath(ApplicationLocator.DOB_year);
	
	By year_num= By.xpath(ApplicationLocator.year_num);
	
	By month_click= By.xpath(ApplicationLocator.Month_click);
	
	By month_select= By.xpath(ApplicationLocator.Month_select);
	
	By date_click= By.xpath(ApplicationLocator.Date_click);
	
	By date_select= By.xpath(ApplicationLocator.Date_num);
	
	By password= By.xpath(ApplicationLocator.Password);
	
	By confirm_Password= By.xpath(ApplicationLocator.Confirm_password);
	
	By submitbttn= By.xpath(ApplicationLocator.Submit);
	
//	public Register_Page_object(WebDriver driver)
//	{
//		this.driver=driver;
//	}
	
	public String Verify_title()
	{
		return driver.getTitle();
	}
	
	
	public void setFirstName(String firstname) throws IOException
	{
		try {
		//wait(ApplicationLocator.First_name,5,"Firstname");
		//String Firstname= excelbook.readExcel(1, 0,"Testdata");
		driver.findElement(fname).sendKeys(firstname);
		htmlReportManager.extentTest.log(Status.PASS, "Firstname Passed");
		}
		catch(Exception e)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Firstname Exception Failed "+ ", " +e.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		
		catch(AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Firstname Assert Failed "+ ", " +aa.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setlastname(String lastname) throws IOException
	{
		try {
		//wait(ApplicationLocator.Last_name,5,"Lastname");
		//String Lastname= excelbook.readExcel(1, 1);
		driver.findElement(lname).sendKeys(lastname);
		htmlReportManager.extentTest.log(Status.PASS, "Lastname Passed");
		}
		catch(Exception e)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Lastname Exception Failed "+ ", " +e.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		
		catch(AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Lastname Assert Failed "+ ", " +aa.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setaddress(String homeaddress) throws IOException
	{
		try {
		//wait(ApplicationLocator.Address,5,"Address");
		//String Address= excelbook.readExcel(1, 2);
		driver.findElement(address).sendKeys(homeaddress);
		htmlReportManager.extentTest.log(Status.PASS, "Address Passed");
		}
		catch(Exception e)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Address Exception Failed "+ ", " +e.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch(AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Address Assert Failed "+ ", " +aa.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		
	}
	
	
	
	public void setemail(String useremail) throws IOException
	{
		try {
		//wait(ApplicationLocator.Email,5,"Email");
		//String Email= excelbook.readExcel(1, 3);
		driver.findElement(email).sendKeys(useremail);
		htmlReportManager.extentTest.log(Status.PASS, "Email Passed");
		}
		catch(Exception e)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Email Exception Failed "+ ", " +e.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		
		catch(AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Email Assert Failed "+ ", " +aa.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		
	}
	
	
	
	public void setphone(String userphone) throws IOException
	{
		try {
		//wait(ApplicationLocator.Phone,5,"Phone");
		//String Phone= excelbook.readExcel(1, 4);
		driver.findElement(phone).sendKeys(userphone);
		htmlReportManager.extentTest.log(Status.PASS, "Phone_Number Passed");
		}
		catch(Exception e)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Phone Exception Failed "+ ", " +e.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		
		catch(AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Phone Assert Failed "+ ", " +aa.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setgender() throws IOException
	{
		try {
			
		//wait(ApplicationLocator.Gender,10,"Gender");
		List<WebElement> genders=driver.findElements(gender);
		boolean flag=false;
		
			for(int i=0;i<genders.size();i++)
				{
					if(genders.get(i).getAttribute("value").contains("FeMale"))
					{
						flag=true;
						genders.get(i).click();
						System.out.println("Gender is selected");
						break;
					}
				}
			if(flag==true)
			{
			htmlReportManager.extentTest.log(Status.PASS, "Gender Passed");
			}
			
			else 
			{
				Assert.fail("Gender is not selected");
			}
		}
		catch(Exception e)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Gender Exception Failed "+ ", " +e.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch(AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Gender Assert Failed "+ ", " +aa.getMessage() +", "
			+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void sethobby() throws IOException
	{
		try {
			
		//wait(ApplicationLocator.Hobbies,10,"Hobby");
		
		List<WebElement> userhobby= driver.findElements(hobbies);
		boolean flag=false;
		
		for(int i=0;i<userhobby.size();i++)
		{
			if(userhobby.get(i).getAttribute("value").contains("Hockey"))
			{
				flag=true;
				userhobby.get(i).click();
				System.out.println("Hobby is selected");
				break;
			}
		}
		if(flag==true)
		{
			htmlReportManager.extentTest.log(Status.PASS, "Hobby Passed");
		}
		else
		{
			Assert.fail("Hobby is not selected");
		}
		}
		catch (Exception e) {
			htmlReportManager.extentTest.log(Status.FAIL, "Hobby Exception Failed "+ ", " +e.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch (AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Hobby Assert Failed "+ ", " +aa.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void Click_languages() throws IOException
	{
		try {
		wait(ApplicationLocator.langauage_click,10,"language");
		driver.findElement(language_Click).click();
	
		List<WebElement> lang= driver.findElements(language_select);
		boolean flag=false;
		
		for(int i=0;i<lang.size();i++)
		{
			if(lang.get(i).getText().contains("English"))
			{
				flag=true;
				lang.get(i).click();
				System.out.println("Language is selected");
				break;
			}
		}
		if(flag==true)
		{
			htmlReportManager.extentTest.log(Status.PASS, "Language Passed");
		}
		else
		{
			Assert.fail("Language is not selected");
		}
		}
		catch (Exception e) {
			htmlReportManager.extentTest.log(Status.FAIL, "Language Exception Failed "+ ", " +e.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch (AssertionError aa)
		{
			htmlReportManager.extentTest.log(Status.FAIL, "Language Assert Failed "+ ", " +aa.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setSkill() throws IOException
	{
		try {
		//	wait(ApplicationLocator.Skill,10,"Skill");
		driver.findElement(skill_select);
		
		List<WebElement> skills= driver.findElements(skill_name);
		boolean flag=false;
		for(int i=-0;i<skills.size();i++)
		{
			if(skills.get(i).getText().contains("Windows"))
			{
				flag=true;
				skills.get(i).click();
				System.out.println("Skills are selected");
				break;
			}
		}
		if(flag==true)
		{
			htmlReportManager.extentTest.log(Status.PASS, "Skill Passed");
		}
		else
		{
			//Assert.fail("Language is not selected");
		}
		}
		catch (Exception e) {
			
			htmlReportManager.extentTest.log(Status.FAIL, "Skill Exception Failed "+ ", " +e.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch (AssertionError aa){
			
			htmlReportManager.extentTest.log(Status.FAIL, "Skill Assert Failed "+ ", " +aa.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setbirth_year() throws IOException
	{
		try {
		//wait(ApplicationLocator.DOB_year,10,"DOB");
		driver.findElement(year_click).click();
		
		List<WebElement> year=driver.findElements(year_num);
		boolean flag= false;
		
		for(int i=0;i<year.size();i++)
		{
			if(year.get(i).getText().contains("1997"))
			{
				flag=true;
				year.get(i).click();
				System.out.println("year is slected");
				break;
			}
		}
		
		if(flag==true)
		{
			htmlReportManager.extentTest.log(Status.PASS, "Birth_year Passed");
		}
		else
		{
			Assert.fail("Year is not selected");
		}
		}
		catch (Exception e) {
			
			htmlReportManager.extentTest.log(Status.FAIL, "Birth_year Exception Failed "+ ", " +e.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch (AssertionError aa){
			
			htmlReportManager.extentTest.log(Status.FAIL, "Birth_year Assert Failed "+ ", " +aa.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setbirth_month() throws IOException
	{
		try {
		wait(ApplicationLocator.Month_click,10,"Month");
		driver.findElement(month_click);
		
		List<WebElement> months= driver.findElements(month_select);
		boolean flag=false;
		for(int i=0;i<months.size();i++)
		{
			if(months.get(i).getText().contains("December"))
			{
				flag=true;
				months.get(i).click();
				System.out.println("month is Selected");
				break;
			}
		}
		if(flag==true)
		{
			htmlReportManager.extentTest.log(Status.PASS, "Birth_month Passed");
		}
		else
		{
			Assert.fail("Month is not selected");
		}
		}
		catch (Exception e) {
			
			htmlReportManager.extentTest.log(Status.FAIL, "Birth_month Exception Failed "+ ", " +e.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch (AssertionError aa){
			
			htmlReportManager.extentTest.log(Status.FAIL, "Birth_month Assert Failed "+ ", " +aa.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setbirth_date() throws IOException
	{
		try {
		wait(ApplicationLocator.Date_click,10,"Date");
		driver.findElement(date_click);
		
		List<WebElement> date= driver.findElements(date_select);
		boolean flag= false;
		for(int i=0;i<date.size();i++)
		{
			if(date.get(i).getText().contains("20"))
			{
				flag= true;
				date.get(i).click();
				System.out.println("date is selected");
				break;
			}
		}
		if(flag==true)
		{
			htmlReportManager.extentTest.log(Status.PASS, "Birth_date Passed");
		}
		else
		{
			Assert.fail("Month is not selected");
		}
		}
		catch (Exception e) {
			
			htmlReportManager.extentTest.log(Status.FAIL, "Birth_date Exception Failed "+ ", " +e.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
		catch (AssertionError aa){
			
			htmlReportManager.extentTest.log(Status.FAIL, "Birth_date Assert Failed "+ ", " +aa.getMessage() +", "
					+ htmlReportManager.extentTest.addScreenCaptureFromPath(getScreenPath()));
		}
	}
	
	
	public void setPassword(String pass) throws IOException
	{
		wait(ApplicationLocator.Password,10,"userPassword");
		//String Password= excelbook.readExcel(1, 5);
		driver.findElement(password).sendKeys(pass);
	}
	
	public void setConfPass(String Cpass) throws IOException
	{
	wait(ApplicationLocator.Confirm_password,10,"userConfirmPassword");
		//String ConfirmPassword= excelbook.readExcel(1, 6);
		driver.findElement(confirm_Password).sendKeys(Cpass);
	}
	
	public void submitbutton()
	{
	wait(ApplicationLocator.Submit,10,"Submit_Button");
		driver.findElement(submitbttn).click();
	}
	
}
