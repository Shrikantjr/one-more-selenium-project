package com.bdd.stepdefinitions;

import com.aventstack.extentreports.Status;
import com.bdd.base.Base_Class;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Step extends Base_Class{

	public Step(){
		
	}
	@Before
	public void printScenariosName(Scenario scenario)
	{
		System.out.println(scenario.getName()+" EXECUTION IS STARTED");
		htmlReportManager.createHtmlReport(scenario.getName());
		htmlReportManager.creatTestReport(scenario.getName());
		htmlReportManager.extentTest.log(Status.INFO, scenario.getName()+" Execution is started");
	}
	
	@After
	public void afterScenario(Scenario scenario)
	{
		System.out.println(scenario.getName()+" EXECUTION IS COMPLETED");
		htmlReportManager.extentTest.log(Status.INFO, scenario.getName()+" Execution is completed");
		htmlReportManager.saveReport();
	}
}
