package com.bdd.impl;

import com.bdd.base.Base_Class;
import static com.bdd.base.Base_Class.*;

public class Implementation  {

	public static void urlAccess()
	{
		if(driver==null || driver.toString().contains("null"))
		{
			driver=  getDriver();
		}
		openUrl();
	}
	public static void openUrl()
	{
		 driver.get("http://demo.automationtesting.in/Register.html");
		  
	}
	
}
