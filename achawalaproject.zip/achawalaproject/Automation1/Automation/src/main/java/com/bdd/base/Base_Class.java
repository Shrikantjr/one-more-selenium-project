package com.bdd.base;

import com.bdd.extentreports.SetExtentReport;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Base_Class {


	public static WebDriver driver;
	protected SetExtentReport htmlReportManager;
//	public static ExtentReports report;
//	public static ExtentSparkReporter reporter;
//	public static ExtentTest test;
	
	public Base_Class()
	{
		htmlReportManager=  htmlReportManager.getInstance();
	}
	
	public static  WebDriver getDriver()
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HD273UW\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
	
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Utility.Implecitly_Timeout));
		return driver;
	}
	
	public static void wait(String element, int time, String elementname)
	{
		try {
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
		}
		
		catch(Exception e)
		{
			Assert.fail("element"+elementname+"is not displayed");
		}
		
	}

	 
	
	public  String getScreenPath() throws IOException
	{
		TakesScreenshot sc= (TakesScreenshot)driver;
		File source= sc.getScreenshotAs(OutputType.FILE);
		String destinationfile=System.getProperty("user.dir")+"\\Screenshots\\"+new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date())+".png";
		FileUtils.copyFile(source, new File(destinationfile));
		return destinationfile;
	}

}
