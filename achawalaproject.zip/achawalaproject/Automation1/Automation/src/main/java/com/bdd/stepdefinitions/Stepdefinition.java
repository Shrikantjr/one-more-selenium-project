package com.bdd.stepdefinitions;

import com.bdd.base.Base_Class;
import com.bdd.excelreader.ReadExcel;
import com.bdd.pageobject.Register_Page_object;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;

import static com.bdd.impl.Implementation.urlAccess;



public class Stepdefinition extends Base_Class {
	Register_Page_object obj= new Register_Page_object();
	ReadExcel excelbook= new ReadExcel();
	
	
	
	
	@Given("I will navigate to Register form")
	public void i_will_navigate_to_register_form() throws IOException{
	
		urlAccess();
		//getScreenPath("abc");		
	}
	
	@When("I will be on sign up page")
	public void i_will_be_on_sign_up_page() {
		String title= driver.getTitle();
		//Assert.assertEquals("Register", title);
		System.out.println("Title matched");
				
	}

	@When("^I have entered Firstname \"(.*)\"$")
	public void i_have_entered_firstname(String FirstName) throws IOException {
		String Firstname= excelbook.readExcel(1, 0,"Testdata");
//		System.out.println("this is exceldata: "+valued);
			
		obj.setFirstName(Firstname); 
	
	}
	
	@When("^I have entered LastName \"(.*)\"$")
	public void i_have_entered_last_name(String LastName) throws IOException {
		
		String Lastname= excelbook.readExcel(1, 1,"Testdata");
	    obj.setlastname(Lastname);
	  
	   
	}

	@When("^I have entered Address \"(.*)\"$")
	public void i_have_entered_address(String Address) throws IOException {
		
		String address= excelbook.readExcel(1, 2,"Testdata");
	    obj.setaddress(address);
	   
	}

	@When("^I have entered EmailAddress \"(.*)\"$")
	public void i_have_entered_email_address(String Email) throws IOException {
		
		String email= excelbook.readExcel(1, 3,"Testdata");
	    obj.setemail(email);
	  
	}

	@When("^I have entered Phone \"(.*)\"$")
	public void i_have_entered_phone(String Phone) throws IOException {
		
		String phone= excelbook.readExcel(1, 4,"Testdata");
	    obj.setphone(phone);
	   
	}

	@When("I have entered Gender")
	public void i_have_entered_gender() throws IOException {
		
		
	    obj.setgender();
	   
	}

	@When("I have entered Hobbies")
	public void i_have_entered_hobbies() throws IOException {
	  obj.sethobby();
	  
	}

	@When("I have entered languages")
	public void i_have_entered_languages() throws IOException {
		
	    obj.Click_languages();
	 
	}

	@When("I have entered Skills")
	public void i_have_entered_skills() throws IOException {
		
	   obj.setSkill();
	 
	}

	@When("I have entered Birth Year")
	public void i_have_entered_birth_year() throws IOException {
	   
		obj.setbirth_year();	
	}

	@When("I have entered Birth Month")
	public void i_have_entered_birth_month() throws IOException {
	 
		obj.setbirth_month();
		
	}

	@When("I have entered Birth Date")
	public void i_have_entered_birth_date() throws IOException {
	    
		obj.setbirth_date();	
	}
	

	@When("^I have entered Password \"(.*)\"$")
	public void i_have_entered_password(String Password) throws IOException {
	    
		String password= excelbook.readExcel(1, 5,"Testdata");

		obj.setPassword(password);
		
	}

	@When("^I have entred ConfirmPassword \"(.*)\"$")
	public void i_have_entred_confirm_password(String ConfirmPassword) throws IOException {
	    
		String confirmPassword= excelbook.readExcel(1, 6,"Testdata");
		obj.setConfPass(confirmPassword);	
	}

	@Then("I Click on Submit button")
	public void i_click_on_submit_button() {
		
		obj.submitbutton();
		
	}
	@And("close browser")
	public void close_browser() {
		
	    driver.close();
	  
	}
}
