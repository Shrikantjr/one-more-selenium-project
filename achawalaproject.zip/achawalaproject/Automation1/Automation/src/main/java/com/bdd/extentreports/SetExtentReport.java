package com.bdd.extentreports;

import java.io.File;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.ResourceCDN;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class SetExtentReport {

	ExtentHtmlReporter htmlReporter;
	ExtentReports extentReports;
	//int count=0;
	public ExtentTest extentTest;
	
	private SetExtentReport()
	{
	}
		public static SetExtentReport getInstance()
		{
			return HtmlReportManagerHolder.htmlReportManager;
		}
		
		private static class HtmlReportManagerHolder{
			public static final SetExtentReport htmlReportManager= new SetExtentReport();
			
		}
		
		protected Object readResolve()
		{
			return getInstance();
		}
		
	public void createHtmlReport(String testCaseName)
	{
		htmlReporter= new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/"+testCaseName+"_"+new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date())+".html");
		htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir")+"//extentreport.xml"));
		htmlReporter.config().setResourceCDN(ResourceCDN.EXTENTREPORTS);
		htmlReporter.setAppendExisting(true);
		extentReports= new ExtentReports();
		extentReports.attachReporter(htmlReporter);
		extentReports.setSystemInfo("Device OS", "Windows 10");
		extentReports.setSystemInfo("Environment", "Production");
		extentReports.setSystemInfo("Tester", "Rishabh");
	}
	
	public void creatTestReport(String testCaseName)
	{
		extentTest=extentReports.createTest(testCaseName);
	}
	
	public void saveReport()
	{
		extentReports.flush();
		htmlReporter=null;
		extentReports=null;
		extentTest=null;
	}
	
}
