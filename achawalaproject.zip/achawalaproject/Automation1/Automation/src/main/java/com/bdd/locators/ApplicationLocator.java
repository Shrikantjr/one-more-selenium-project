package com.bdd.locators;

public class ApplicationLocator {

	public static String First_name="//input[@placeholder='First Name']";
	
	public static String Last_name="//input[@placeholder='Last Name']";
	
	public static String Address="(//label[text()='Address']/following::div/textarea)";
	
	public static String Email="(//label[text()='Email address*']/following::div/input)[position()=1]";
	
	public static String Phone="(//label[text()='Phone*']/following::div/input)[position()=1]";
	
	public static String Gender="//label[text()='Gender*']/following::div/label/input";
	
	public static String Hobbies="//label[text()='Hobbies']/following::div/div/input[@type='checkbox']";
	
	public static String langauage_click="(//label[text()='Languages']/following::div/multi-select/div)[position()=1]";
	
	public static String language_Select="//label[text()='Languages']/following::div/multi-select/div[2]//li/a";
	
	public static String Skill="//label[text()='Skills']";
	
	public static String Skill_click="(//label[text()='Skills']/following::div/select)[position()=1]";
	
	public static String Skill_name="//label[text()='Skills']/following::div/select[@id='Skills']/option";
	
	public static String DOB_year="//select[@id='yearbox']";
	
	public static String year_num="//label[text()='Date Of Birth']/following::div/select[@id='yearbox']/option";
	
	public static String Month_click="//select[@placeholder='Month']";
	
	public static String Month_select="//select[@placeholder='Month']/option";
	
	public static String Date_click="//select[@id='daybox']";
	
	public static String Date_num="//select[@id='daybox']/option";
	
	public static String Password="//input[@id='firstpassword']";
	
	public static String Confirm_password="(//label[contains(text(),'Confirm Password')]/following::div/input[@id='secondpassword'])";
	
	public static String Submit="//button[@id='submitbtn']";
	
	
	
	
	
}
