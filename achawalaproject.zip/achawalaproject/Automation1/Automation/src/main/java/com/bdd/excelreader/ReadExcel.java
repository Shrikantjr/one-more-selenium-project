package com.bdd.excelreader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	
	public String readExcel(int row, int col, String sheets) throws IOException
	{
		
//		File file= new File("C:\\Users\\10706607\\Desktop\\Excel_BDD.xlsx");
		//ArrayList<String> exceldata= new ArrayList<String>();
		FileInputStream files= new FileInputStream("filepath");
		XSSFWorkbook workbook= new XSSFWorkbook(files);
		
		XSSFSheet sheet= workbook.getSheet(sheets);
		
//			int lastrowindex= sheet.getLastRowNum();
		
//			for(int i=0;i<lastrowindex;i++)
//			{
//				Row row= sheet.getRow(i);
//				int lastcellindex =row.getLastCellNum();
//				
//				for(int j=0;j<lastcellindex;j++)
//				{
//					Cell cell= row.getCell(j);
//					System.out.println(cell+" ");
//				}
//				System.out.println();
//			}
//			files.close();
//		}
		
		String value= sheet.getRow(row).getCell(col).toString();

		files.close();
		return value;
	}
	
	
}
